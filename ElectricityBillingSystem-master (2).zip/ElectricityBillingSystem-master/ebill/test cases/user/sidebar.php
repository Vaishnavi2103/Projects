<!-- Sidebar -->
<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="active">
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li>
            <a href="bill.php"><i class="fa fa-fw fa-bar-chart-o"></i> BILLS </a>
        </li>
        <!-- new bills by bootstrap badges -->
        <li>
            <a href="transaction.php"><i class="fa fa-fw fa-table"></i> TRANSACTION </a>
        </li>
        <li>
            <a href="complaint.php"><i class="fa fa-fw fa-edit"></i> COMPLAINTS </a>
        </li>
        <!-- processed bills as bootstrap badges -->
    </ul>
</div>
<!-- /#sidebar-wrapper -->
