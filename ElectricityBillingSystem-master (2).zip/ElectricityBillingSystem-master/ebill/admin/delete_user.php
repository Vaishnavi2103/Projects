<?php 
include("../Includes/config.php");
extract($_GET);
$get = $con->query("SELECT * FROM user where id=  $id")->fetch_array();
$qry = $con->query("DELETE FROM user where id = $id" );
$qry2 = $con->query("DELETE FROM user where id = '".$get['id']."' ");
if ($qry && $qry2)
	echo true;
	header("location:users.php")
	
?>
