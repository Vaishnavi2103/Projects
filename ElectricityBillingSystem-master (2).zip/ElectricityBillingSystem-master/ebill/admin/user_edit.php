<?php 
include("Includes/config.php");
extract($_GET);
$get = $conn->query("SELECT * FROM user where id= ".$id)->fetch_array();
$qry = $conn->query("UPDATE FROM user SET id = .$id where email=" .$email);

if($qry && $qry2)
	echo true;
?>