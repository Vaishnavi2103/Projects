<?php 
include("../Includes/config.php");
extract($_GET);
$get = $conn->query("SELECT * FROM user where id= ".$id)->fetch_array();
$qry = $conn->query("UPDATE user SET email = '".$email."',
                        SET phone='".$phone."',
                        SET name='".$name."',
                        SET address='".$address."',
                         where id=" .$id);
if($qry && $qry2)
	echo true;
    header("location:users.php")
?>